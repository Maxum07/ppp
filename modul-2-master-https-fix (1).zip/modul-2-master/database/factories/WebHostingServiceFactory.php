<?php

namespace Database\Factories;

use App\Models\WebHostingService;
use Illuminate\Database\Eloquent\Factories\Factory;

class WebHostingServiceFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = WebHostingService::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            //
        ];
    }
}
