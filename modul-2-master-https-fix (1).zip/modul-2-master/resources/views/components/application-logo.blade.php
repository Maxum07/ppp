<div class="text-blue-400 text-xl">
  <i class="fas fa-cloud"></i> <b>Portal - SMK Cloud Provider</b>
</div>
